"""
GUI is modeled here

tools - Tkinter / Kivy/ Dash
"""